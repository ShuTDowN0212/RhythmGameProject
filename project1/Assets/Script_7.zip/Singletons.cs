﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Singletons : MonoBehaviour  //인 게임 싱글톤
{
    public static int perfect = 0;
    public static int great = 0;
    public static int miss = 0;

    public static int combo = 0; //현재 콤보

    public static float ComboPoint = 0; //계산전 정확도
    public static int NoteCount = 0; // 계산시 필요한 노트카운트

    public static int bestScore = 0; //베스트 스코어

    public static float musicVolume = 1f;

    public static string NowAcc; //계산 후 정확도


    public static GameObject missBlock;

    private void Awake()
    {
        missBlock = GameObject.Find("MissCheck");

    }

    private int currentCombo;
    public Text comboText;

    public Text AccText;


    public void FixedUpdate(){
        string comboNum = combo.ToString();
        comboText.text = comboNum;

        if (combo > bestScore)
        {
            bestScore = combo;
        }

        AccText.text = NowAcc;
    }
   
}
