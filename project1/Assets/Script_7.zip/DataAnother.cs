﻿using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;


public class DataAnother : MonoBehaviour
{
    int[] _data;

    string _tmpStr = "";

    public void Awake()
    {
        for (int i = 0; i < _data.Length; i++)
        {
            _tmpStr = _tmpStr + _data[i];
            if (i < _data.Length)
            {
                _tmpStr = _tmpStr + ",";
            }
        }

        Load02();
    }


    public void Load02()
    {
        string[] _dataArr = PlayerPrefs.GetString("Data").Split(',');
        int[] _dataIn = new int[_dataArr.Length];
        for (int i = 0; i < _dataArr.Length; i++)
        {
            _dataIn[i] = System.Convert.ToInt32(_dataArr[i]);
        }
    }

    public void Save02()
    {
        PlayerPrefs.SetString("Data", _tmpStr);
    }
}