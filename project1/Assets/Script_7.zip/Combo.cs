﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Combo : MonoBehaviour  //스크립트 이름 그 자체/ 콤보들 관련 함수모음
{

    public static float AllAccuracy;
    public static int AllNotes = SelectSingleton.NoteData;


    public void Start()
    {
        AllAccuracy = 0;
    }

    public void FixedUpdate()
    {
        Singletons.NowAcc = AllAccuracy.ToString();
    }


    public static void comboperfect(){

        Singletons.combo =+ 1;
        Singletons.NoteCount++;
        Singletons.ComboPoint =+ 1;
        AllAccuracy = comboAccuracycircule(Singletons.NoteCount, Singletons.combo);
    }

    public static void combogreat(){
        Singletons.combo = +1;
        Singletons.NoteCount++;
        Singletons.ComboPoint =+ 0.7f;
        AllAccuracy = comboAccuracycircule(Singletons.NoteCount,Singletons.combo);
    }

    public static void combomiss(){
        Singletons.combo = 0;
        Singletons.NoteCount++;
        Singletons.ComboPoint =+ 0;
        AllAccuracy = comboAccuracycircule(Singletons.NoteCount,Singletons.combo);
    }



    public static float comboAccuracycircule(int Notecnt, float Acombo){
        float temp,temp2,temp3;
        temp = Notecnt;
        temp2 = Acombo;
        temp3 = Acombo / Notecnt;

        return temp3;
    }
}
