﻿using System;
using System.Collections;
using UnityEngine;
using System.Collections.Generic;


[System.Serializable]
public class NoteData
{
    public int seq;
    public int NoteX;
    public int NoteY;
    public string NoteType;


}


[System.Serializable]
public class NoteDataArray
{
    public NoteData[] data;
}

public class LoadNoteData : MonoBehaviour
{
    
    TextAsset XYdata;
    NoteDataArray NoteDataXY;
    public GameObject SNOTE;//하위에 이팩트 두기   // Notes1.cs  Effect스크립트
    public GameObject MNOTE;
    public GameObject PNOTE;
    public GameObject NoteParent;  //NoteParent GameObject 정렬을 위한 패런츠

    void Awake()
    {
        SNOTE = GameObject.Find("Forte");
        MNOTE = GameObject.Find("MezoPiano");
        PNOTE = GameObject.Find("Piano");
        NoteParent = GameObject.Find("NoteParent");
        NoteData();

        for (int i = 0; i < NoteDataXY.data.Length; i++)
        {
            if(NoteDataXY.data[i].NoteType == "Forte")
            {
                Vector3 NoteVec = new Vector3(NoteDataXY.data[i].NoteX, NoteDataXY.data[i].NoteY, 0);
                GameObject Note = Instantiate(SNOTE,NoteVec,Quaternion.identity) as GameObject;
                Note.transform.SetParent(NoteParent.transform);
                Note.gameObject.tag = "Strong";
                Note.transform.Translate(NoteVec);
            }

            if (NoteDataXY.data[i].NoteType == "MezoPiano")
            {
                Vector3 NoteVec = new Vector3(NoteDataXY.data[i].NoteX, NoteDataXY.data[i].NoteY, 0);
                GameObject Note = Instantiate(MNOTE, NoteVec, Quaternion.identity) as GameObject;
                Note.transform.SetParent(NoteParent.transform);
                Note.gameObject.tag = "MezoPiano";
                Note.transform.Translate(NoteVec);
            }

            if (NoteDataXY.data[i].NoteType == "Piano")
            {
                Vector3 NoteVec = new Vector3(NoteDataXY.data[i].NoteX, NoteDataXY.data[i].NoteY, 0);
                GameObject Note = Instantiate(PNOTE, NoteVec, Quaternion.identity) as GameObject;
                Note.transform.SetParent(NoteParent.transform);
                Note.gameObject.tag = "Piano";
                Note.transform.Translate(NoteVec);
            }
        }
    }



    public void NoteData()
    {

        string DataName = SelectSingleton.SceneName;

        XYdata = Resources.Load(DataName) as TextAsset;
        NoteDataXY = JsonUtility.FromJson<NoteDataArray>(XYdata.ToString());
        Debug.Log(NoteDataXY.data[0].NoteX);
    }
}




