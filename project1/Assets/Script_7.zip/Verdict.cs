﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEditor;

public class Verdict : MonoBehaviour { //노트에 붙이는거


    public static Collider2D other;

    public AudioSource Perfect;
    public AudioSource Great;

    Combo combo;

    private void Awake()
    {
        
    }

    // Use this for initialization
    void Start () {
        other = GetComponent<Collider2D>();
	}
	
	// Update is called once per frame
	void Update () {

	}


    public void OnTriggerEnter(Collider2D other)
    {
        if(other.gameObject.tag == "PerfectCollider") {
            Singletons.perfect++;
            Combo.comboperfect();
            Perfect.Play();
        }

        if (other.gameObject.tag != "PerfectCollider" && other.gameObject.tag == "GreatCollider")
        {
            Singletons.great++;
            Combo.combogreat();
            Great.Play();
        }
        
        if (other.gameObject.tag == "MissLine" || other.gameObject.tag != "GreatCollider")
        {
            Singletons.miss++;
            Combo.combomiss();
        }

        else
        {
            Singletons.miss++;
            Combo.combomiss();
        }

        PanelTouch.isTouch = false;
    }
}
