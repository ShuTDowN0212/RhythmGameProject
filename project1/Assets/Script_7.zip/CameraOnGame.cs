﻿using System;
using System.Collections;
using UnityEngine;
using UnityEngine.UI;


public class CameraOnGame
{
    public static GameObject SubCamera = GameObject.Find("SubCamera");

    public void Awake()
    {
        SubCamera.SetActive(false);
    }

    public static void StopCamera()
    {
        SubCamera.SetActive(true);
    }

    public static void ResumeCamera()
    {
        SubCamera.SetActive(false);
    }
}