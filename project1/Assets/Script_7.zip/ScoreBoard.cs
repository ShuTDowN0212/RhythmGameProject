using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class ScoreBoard : MonoBehaviour  //���ھ� ���� ���� ��ũ��Ʈ  //������ ����
{
    public Button GoToSelect;

    public AudioSource BackSound;
    public AudioClip BackSound_;

    public static float BestPoint;

    public Texture NewRecord;
    public Texture NRecord;

    public Text PerfectText;
    public Text GreatText;
    public Text MissText;
    public Text AccuracyText;
    public Text BestAccuracy;
    public Text BestCombo;

    public GameObject GameSingletons = GameObject.Find("Singleton");

    public void Awake()
    {
        if(SaveAndLoadData.Point < BestPoint)
        {
            NewRecord = null;
            BestPoint = SaveAndLoadData.HighScoreSaved[SelectSingleton.StageNum];
        }
        else
        {
            NewRecord = NRecord;
            SaveAndLoadData.HighScore[SelectSingleton.StageNum] = Singletons.bestScore.ToString();
        }

        SaveAndLoadData.SaveData();
        ScoreView();
    }
    
    public void Start(){
        BackSound = GetComponent<AudioSource>();
        BackSound.clip = BackSound_;
        BackSound.loop = false;

        BestPoint = Combo.AllAccuracy;


        }

    public void Update()
    {
        if (GoToSelect && Input.GetMouseButtonDown(0)) { OnClickGoToSelect();  }
    }



    public void OnClickGoToSelect()
    {
        BackSound.Play();

        Destroy(GameSingletons);
        SelectSingleton.SceneName = null;
        SceneManager.LoadScene("SelectStage");
        SaveAndLoadData.LoadData();
    }

    public void ScoreView()
    {
        PerfectText.text = Singletons.perfect.ToString();
        GreatText.text = Singletons.great.ToString();
        MissText.text = Singletons.miss.ToString();
        AccuracyText.text = Singletons.NowAcc.ToString();
        BestAccuracy.text = SaveAndLoadData.Point.ToString();
        BestCombo.text = Singletons.bestScore.ToString();
    }

    public void ReplayGame()
    {
        BackSound.Play();
        SceneManager.LoadScene("Loading");

    }
}