﻿using System;
using System.Collections;
using UnityEngine;
using UnityEngine.UI;

public class PanelTouch : MonoBehaviour  //터치 판넬에 붙이기
{
    public static float TouchPressure;

    EffectManager effectManager;

    public static bool isTouch = false;

    public Collider2D PerfectCollider;
    public Collider2D GreatCollider;

    public void Awake()
    {
        effectManager = GetComponentInChildren<EffectManager>();

        PerfectCollider.enabled = false;
        GreatCollider.enabled = false;
    }

    public void FixedUpdate()
    {
        if (Input.touchCount > 0)
        {
            Touch touch = Input.GetTouch(0);

            TouchPressure = Input.GetTouch(0).pressure;

            effectManager.StartEffect("Touched");

            switch (touch.phase)
            {
                case TouchPhase.Began:
                    PerfectCollider.enabled = true;
                    GreatCollider.enabled = true;
                    VerdictPressure.OnTouched = true;
                    isTouch = true;
                    break;
                case TouchPhase.Stationary:
                    if (isTouch == false)
                    {
                        PerfectCollider.enabled = false;
                        GreatCollider.enabled = false;
                        VerdictPressure.OnTouched = false;
                    }
                    break;
                case TouchPhase.Ended:
                    PerfectCollider.enabled = false;
                    GreatCollider.enabled = false;
                    VerdictPressure.OnTouched = false;
                    break;
            }


        }
    }
}
