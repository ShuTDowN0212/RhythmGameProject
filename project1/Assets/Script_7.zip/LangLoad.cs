﻿using System;
using System.Collections;
using UnityEngine;

[System.Serializable]
public class LangLoad
{
    public int seq;
    public string ko;
    public string en;
    public string jp;
}



[System.Serializable]
public class LangLoadArray
{
    public LangLoad[] data;
}

public class StartLang : MonoBehaviour
{
    TextAsset textData;
    LangLoadArray myText;

    private void Start()
    {
        textData = Resources.Load("txt_data") as TextAsset;
        myText = JsonUtility.FromJson<LangLoadArray>(textData.ToString());
        Debug.Log(myText.data[0].ko);
    }

}

