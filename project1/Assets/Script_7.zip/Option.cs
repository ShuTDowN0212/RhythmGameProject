using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Option : MonoBehaviour
{
    public static int UserSpeed = 3;

    public void OnClickDownSpeed()
    {
        UserSpeed =- 1;
    }
    public void OnClickUpSpeed()
    {
        UserSpeed =+ 1;
    }


    public void OnClickResetSpeed()
    {
        UserSpeed = 3;
    }
}